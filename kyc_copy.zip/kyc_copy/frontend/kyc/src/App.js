import React from 'react';
import AdminPortal from './components/AdminPortal';
function App() {
  return (
    <div className="App">
      <AdminPortal />
    </div>
  );
}

export default App;

