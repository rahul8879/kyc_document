import React from 'react'


const routes = [
  { path: '/', exact: true, name: 'Home' }
 
]

export default routes
